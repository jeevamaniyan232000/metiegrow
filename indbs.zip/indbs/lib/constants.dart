const String titleName = "Relax Bike Rental ";
const String slogan = "Hello again";
const String textdescription = "Welcome back you've been missed!";
const String sloganName = "Trip must";
const String alreadyaccount = "Already  have account?";
