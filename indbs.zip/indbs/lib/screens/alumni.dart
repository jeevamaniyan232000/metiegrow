import 'package:app/screens/lawyer.dart';
import 'package:app/screens/question.dart';
import 'package:flutter/material.dart';
class AlumniScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Alumni List'),
          backgroundColor: Colors.purple,
          foregroundColor:Colors.white,
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.purple,
                ),
                child: Text(
                  'Navigation Menu',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                  ),
                ),
              ),
              ListTile(
                leading: Icon(Icons.home, color: Colors.purple),
                title: Text('Home'),
                onTap: () {},
              ),
              ListTile(
                leading: Icon(Icons.school, color: Colors.purple),
                title: Text('Mentorship'),
                onTap: () {},
              ),
              ListTile(
                leading: Icon(Icons.question_answer, color: Colors.purple),
                title: Text('Q&A'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => QuestionScreen()),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.gavel, color: Colors.purple),
                title: Text('Lawyer'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LawyerListScreen()),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.people, color: Colors.purple),
                title: Text('Alumni'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AlumniScreen()),
                  );
                },
              ),
            ],
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Container(
              padding: const EdgeInsets.all(20.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 2,
                    blurRadius: 7,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Text(
                'No alumnis',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ),
        backgroundColor: Colors.grey[200],
      ),
    );
  }
}