import 'package:app/screens/alumni.dart';
import 'package:app/screens/lawyer.dart';
import 'package:app/screens/mentorship.dart';
import 'package:app/screens/question.dart';
import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications),
            onPressed: () {},
          ),
          CircleAvatar(
            backgroundImage: AssetImage('assets/images/pexels-stefanstefancik-91227.jpg'), // Replace with actual image URL or asset
          ),
          SizedBox(width: 8.0),
          Center(
            child: Text('Robert Kinimon'),
          ),
          SizedBox(width: 16.0),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Profile Status and Wallet Balance Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildStatusCard('Profile Status', '75% completed', Icons.edit),
                _buildStatusCard('Wallet Balance', '₹2000', Icons.add),
              ],
            ),
            SizedBox(height: 16.0),
            // New Session
            _buildSessionCard(),
            SizedBox(height: 16.0),
            // Mentors, Lawyer, Alumni Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildInfoCard('Mentors', 'View all', 'Robert Kinimon', 'Web Developer | TCS', '15 years of experience', '₹4500/mo'),
                _buildInfoCard('Lawyer', 'View all', 'Robert Kinimon', 'Web Developer | TCS', '15 years of experience', '₹4500/mo'),
                _buildInfoCard('Alumni', 'View all', 'Robert Kinimon', 'Web Developer | TCS', '15 years of experience', '₹4500/mo'),
              ],
            ),
            SizedBox(height: 16.0),
            // Recent Sessions Container
            Container(
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Recent Sessions', style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8.0),
                  _buildRecentSessionItem('14th Jun 2024', '2:30 pm - 3:00 pm', 5),
                  _buildRecentSessionItem('14th Jun 2024', '2:30 pm - 3:00 pm', 4),
                  _buildRecentSessionItem('14th Jun 2024', '2:30 pm - 3:00 pm', 3),
                ],
              ),
            ),
            SizedBox(height: 16.0),
            // Recent Chats Container
            Container(
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 5,
                    offset: Offset(0, 3), // changes position of shadow
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Recent Chats', style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8.0),
                  _buildRecentChatItem('Robert Kinimon', 'Web Developer'),
                  _buildRecentChatItem('Robert Kinimon', 'Web Developer'),
                  // Add more recent chat items here
                ],
              ),
            ),
          ],
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.purple,
              ),
              child: Text(
                'Navigation Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: Colors.purple),
              title: Text('Home'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.school, color: Colors.purple),
              title: Text('Mentorship'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => MentorshipScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.question_answer, color: Colors.purple),
              title: Text('Q&A'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => QuestionScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.gavel, color: Colors.purple),
              title: Text('Lawyer'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => LawyerListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.people, color: Colors.purple),
              title: Text('Alumni'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => AlumniScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCard(String title, String subtitle, IconData icon) {
    return Expanded(
      child: Card(
        color: Colors.purple[100],
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: Colors.purple),
                  SizedBox(width: 8.0),
                  Text(title, style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
                ],
              ),
              SizedBox(height: 8.0),
              Text(subtitle, style: TextStyle(fontSize: 14.0)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSessionCard() {
    return Card(
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            CircleAvatar(
              backgroundImage: AssetImage('assets/images/pexels-stefanstefancik-91227.jpg'), // Replace with actual image URL or asset
            ),
            SizedBox(width: 16.0),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Robert Kinimon', style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
                Text('Web Developer', style: TextStyle(fontSize: 14.0, color: Colors.grey)),
                Text('15th Jul - 1:30 PM', style: TextStyle(fontSize: 12.0, color: Colors.grey)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, String viewAll, String name, String role, String experience, String price) {
    return Expanded(
      child: Card(
        color: Colors.white,
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(title, style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
                  Text(viewAll, style: TextStyle(fontSize: 12.0, color: Colors.purple)),
                ],
              ),
              SizedBox(height: 16.0),
              CircleAvatar(
                radius: 30,
                backgroundImage: AssetImage('assets/images/pexels-stefanstefancik-91227.jpg'), // Replace with actual image URL or asset
              ),
              SizedBox(height: 8.0),
              Text(name, style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
              Text(role, style: TextStyle(fontSize: 12.0, color: Colors.grey)),
              Text(experience, style: TextStyle(fontSize: 11.0, color: Colors.grey)),
              SizedBox(height: 8.0),
              Text(price, style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecentSessionItem(String date, String time, int rating) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CircleAvatar(
            backgroundImage: AssetImage('assets/images/pexels-stefanstefancik-91227.jpg'), // Replace with actual image URL or asset
          ),
          SizedBox(width: 8.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Robert Kinimon', style: TextStyle(fontSize: 14.0, fontWeight: FontWeight.bold)),
              Text('Web Developer', style: TextStyle(fontSize: 12.0, color: Colors.grey)),
              Text('$date - $time', style: TextStyle(fontSize: 12.0, color: Colors.grey)),
            ],
          ),
          Spacer(),
          Row(
            children: List.generate(5, (index) {
              return Icon(
                index < rating ? Icons.star : Icons.star_border,
                color: Colors.black54,
                size: 16.0,
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentChatItem(String name, String role) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          CircleAvatar(
            backgroundImage: AssetImage('assets/images/pexels-stefanstefancik-91227.jpg'), // Replace with actual image URL or asset
          ),
          SizedBox(width: 8.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: TextStyle(fontSize: 14.0, fontWeight: FontWeight.bold)),
              Text(role, style: TextStyle(fontSize: 12.0, color: Colors.grey)),
            ],
          ),
        ],
      ),
    );
  }
}
