import 'package:app/screens/alumni.dart';
import 'package:app/screens/question.dart';
import 'package:flutter/material.dart';
class LawyerListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lawyers'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.purple,
              ),
              child: Text(
                'Navigation Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: Colors.purple),
              title: Text('Home'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.school, color: Colors.purple),
              title: Text('Mentorship'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.question_answer, color: Colors.purple),
              title: Text('Q&A'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => QuestionScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.gavel, color: Colors.purple),
              title: Text('Lawyer'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LawyerListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.people, color: Colors.purple),
              title: Text('Alumni'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AlumniScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          LawyerCard(
            name: "Raj L",
            description: "test",
            price: "₹1,000",
            tags: ["test"],
            imageUrl: null, // No image, just initials
            rating: 0,
            reviews: 0,
          ),
          LawyerCard(
            name: "Purvi S",
            description: "advises medium-sized and national law firms on business development and marketing strategy.",
            price: "₹500",
            tags: ["polity", "law"],
            imageUrl: "https://via.placeholder.com/150", // Placeholder image
            rating: 0,
            reviews: 0,
          ),
          LawyerCard(
            name: "Jega S",
            description: "hi i am lawyer",
            price: "₹1,000",
            tags: ["polity", "social"],
            imageUrl: "https://via.placeholder.com/150", // Placeholder image
            rating: 0,
            reviews: 0,
          ),
        ],
      ),
    );
  }
}

class LawyerCard extends StatelessWidget {
  final String name;
  final String description;
  final String price;
  final List<String> tags;
  final String? imageUrl;
  final double rating;
  final int reviews;

  LawyerCard({
    required this.name,
    required this.description,
    required this.price,
    required this.tags,
    this.imageUrl,
    required this.rating,
    required this.reviews,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            imageUrl == null
                ? Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: Colors.purple,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Center(
                child: Text(
                  name.substring(0, 2),
                  style: TextStyle(color: Colors.white, fontSize: 24),
                ),
              ),
            )
                : ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: Image.network(
                imageUrl!,
                width: 60,
                height: 60,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 4),
                  Text(description),
                  SizedBox(height: 8),
                  Wrap(
                    spacing: 4,
                    children: tags.map((tag) {
                      return Chip(
                        label: Text(tag),
                        backgroundColor: Colors.teal[100],
                      );
                    }).toList(),
                  ),
                  SizedBox(height: 8),
                  Text(
                    price,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.purple,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                Icon(Icons.star_border, color: Colors.grey),
                SizedBox(height: 4),
                Text(
                  '$rating (0 reviews)',
                  style: TextStyle(color: Colors.grey),
                ),
                SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.purple,
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  child: Text('View Profile'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
