import 'dart:ui';
import 'package:flutter/material.dart';
import 'viewprofile.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class MentorshipScreen extends StatefulWidget {
  const MentorshipScreen({super.key});

  @override
  State<MentorshipScreen> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MentorshipScreen> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text(''),
      ),
      body: Column(
        children: [
          Card(
            elevation: 2.5,
            child: Container(
              padding: const EdgeInsets.all(8.0),
              height: size.height * 0.37,
              width: size.width,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadiusDirectional.circular(15.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Row(
                    children: [
                      Container(
                        height: size.height * 0.26,
                        width: size.width * 0.35,
                        color: Colors.black,
                      ),
                      SizedBox(
                        width: size.width * 0.05,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Rahul T',
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                          const Text(
                            'Developer',
                            style: TextStyle(fontSize: 16, color: Colors.grey),
                          ),
                          const Text(
                            'Amazon',
                            style: TextStyle(fontSize: 12),
                          ),
                          Row(
                            children: [
                              RatingBar.builder(
                                initialRating: 3,
                                minRating: 1,
                                itemSize: 15,
                                direction: Axis.horizontal,
                                allowHalfRating: true,
                                itemCount: 5,
                                itemPadding:
                                    const EdgeInsets.symmetric(horizontal: 2.0),
                                itemBuilder: (context, _) => const Icon(
                                  Icons.star_outline,
                                  color: Colors.amber,
                                ),
                                onRatingUpdate: (rating) {
                                  print(rating);
                                },
                              ),
                              const Text(
                                '3(1 reviews)',
                                style: TextStyle(fontSize: 12),
                              ),
                            ],
                          ),
                          const Text(
                            'Hi iam a developer',
                            style: TextStyle(fontSize: 12),
                          ),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(5.0),
                                decoration: BoxDecoration(
                                  color: Colors.grey[300],
                                  borderRadius: BorderRadius.circular(20.0),
                                ),
                                child: const Text('HTML'),
                              ),
                              SizedBox(width: size.width * 0.02),
                              Container(
                                padding: const EdgeInsets.all(5.0),
                                decoration: BoxDecoration(
                                  color: Colors.grey[300],
                                  borderRadius:
                                      BorderRadiusDirectional.circular(20.0),
                                ),
                                child: const Text('CSS'),
                              ),
                            ],
                          ),
                          ElevatedButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const ViewProfile(),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.purple,
                                fixedSize: Size(
                                    size.width * 0.53, size.height * 0.05)),
                            child: const Text(
                              'View Profile',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                  const Text(
                    '\u{20B9}1,000',
                    style: TextStyle(fontSize: 20, color: Colors.purple),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
