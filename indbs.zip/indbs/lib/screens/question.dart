import 'package:app/screens/alumni.dart';
import 'package:app/screens/lawyer.dart';
import 'package:flutter/material.dart';
class QuestionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Questions'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black54,
        elevation: 0,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.purple,
              ),
              child: Text(
                'Navigation Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: Colors.purple),
              title: Text('Home'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.school, color: Colors.purple),
              title: Text('Mentorship'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.question_answer, color: Colors.purple),
              title: Text('Q&A'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => QuestionScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.gavel, color: Colors.purple),
              title: Text('Lawyer'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LawyerListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.people, color: Colors.purple),
              title: Text('Alumni'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AlumniScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'Search questions here',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple, // background color
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              child: Center(
                child: Text('Ask a Free Question'),
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Recently Answered Questions on topics',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView(
                children: [
                  QuestionTile(
                    question: 'first question',
                    description: 'hi',
                    views: 0,
                    date: '8/15/2024, 2:19:43 AM',
                  ),
                  QuestionTile(
                    question: 'Pollution',
                    description: 'How to prevent air pollution',
                    views: 0,
                    date: '8/15/2024, 2:19:43 AM',
                  ),
                  QuestionTile(
                    question: 'java',
                    description: 'what is java',
                    views: 0,
                    date: '8/28/2024, 2:19:43 AM',
                  ),
                  // Add more QuestionTile widgets as needed
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class QuestionTile extends StatelessWidget {
  final String question;
  final String description;
  final int views;
  final String date;

  QuestionTile({
    required this.question,
    required this.description,
    required this.views,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            question,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 4),
          Text(description),
          SizedBox(height: 4),
          Text(
            '$views views',
            style: TextStyle(color: Colors.grey),
          ),
          Text(
            'Asked on $date',
            style: TextStyle(color: Colors.grey),
          ),
          Divider(),
        ],
      ),
    );
  }
}
