import 'package:flutter/material.dart';

class TitleScreen extends StatelessWidget {
  TitleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bikes For Rental'),
        backgroundColor: Colors.orange,
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {
            // Handle menu icon press
          },
        ),
        actions: [
          ////
          IconButton(
            icon: const CircleAvatar(
              backgroundImage: AssetImage(
                  'images/profile.jpeg'), // Replace with your image asset path
              radius: 16.0, // Adjust the radius as needed
            ),
            onPressed: () {
              // Handle profile image press
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: ListView(
          children: [
            _buildListItem(
              imagePath:
                  'images/firstimage.png', // Replace with your image asset path
              description: 'Mountain Bike - Perfect for rough terrains.',
            ),
            _buildListItem(
              imagePath:
                  'images/secondimage.png', // Replace with your image asset path
              description: 'Road Bike - Ideal for long-distance rides.',
            ),
            _buildListItem(
              imagePath:
                  'images/thirdimage.png', // Replace with your image asset path
              description: 'Hybrid Bike - Great for city commuting.',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListItem({
    required String imagePath,
    required String description,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey, width: 1.0),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image section
          ClipRRect(
            borderRadius: BorderRadius.horizontal(left: Radius.circular(8.0)),
            child: Image.asset(
              imagePath,
              fit: BoxFit.cover,
              width: 150.0,
              height: 150.0,
            ),
          ),
          SizedBox(width: 10.0),
          // Description and buttons section
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    description,
                    style: TextStyle(fontSize: 16.0),
                  ),
                  Spacer(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () {
                          // Handle view more action
                        },
                        child: Text('View More'),
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.white, // Text color
                          backgroundColor: Colors.orange,
                          padding: EdgeInsets.symmetric(horizontal: 16.0),
                        ),
                      ),
                      SizedBox(width: 8.0),
                      ElevatedButton(
                        onPressed: () {
                          // Handle book now action
                        },
                        child: Text('Book Now'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          padding: EdgeInsets.symmetric(horizontal: 16.0),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}////
