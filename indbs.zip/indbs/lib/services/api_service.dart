import 'package:http/http.dart' as http;
import 'dart:convert';
import '../config/config.dart';

class ApiService {
  // Signup method
  static Future<http.Response> signup({
    required String username,
    required String password,
    required String email,
    required String firstName,
    required String lastName,
    required String phoneNumber,
    required String userRoles,
  }) async {
    final url = Uri.parse('$apiUrl/api/signUp');
    final response = await http.post(
      url,
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, dynamic>{
        'username': username,
        'password': password,
        'email': email,
        'userRoles': ['USER'],
        'firstName': firstName,
        'lastName': lastName,
        'phoneNumber': phoneNumber,
      }),
    );
    return response;
  }

  // Login method
  static Future<http.Response> loginScreen({
    required String username,
    required String password,
  }) async {
    final url = Uri.parse('$apiUrl/api/login');
    final response = await http.post(
      url,
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, dynamic>{
        'username': username,
        'password': password,
      }),
    );
    return response;
  }
}
