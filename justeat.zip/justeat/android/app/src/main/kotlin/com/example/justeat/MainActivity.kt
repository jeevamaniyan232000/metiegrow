package com.example.justeat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
