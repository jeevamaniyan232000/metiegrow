import 'package:flutter/material.dart';
import 'package:justeat/screens/login_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SplashScreen(),
    );
  }
}

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Color
          Container(
            color: Colors.white,
          ),
          // Bottom curved section with orange background
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: MediaQuery.of(context).size.height * 0.5,
              decoration: BoxDecoration(
                color: Color(0xFFFDBD41), // orange color
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(100),
                  topRight: Radius.circular(100),
                ),
              ),
            ),
          ),
          // Content
          Column(
            children: [
              Spacer(),
              // Image Logo
              Center(
                child: Image.asset(
                  'assets/images/register_top.png', // Replace with your actual image path
                  height: 360,
                  width: 300,
                ),
              ),
              Spacer(),
              // Texts and Button
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Column(
                  children: [
                    Text(
                      'The Fastest In Delivery Food',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4), // Reduce space between the title and the description
                    Text(
                      'Our Job is to fill your Yummy with\n delicious food and fast delivery',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black54,
                      ),
                    ),
                    SizedBox(height: 16), // Adjusted to reduce space
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen()), );
                      },
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        padding: EdgeInsets.symmetric(
                          vertical: 16,
                          horizontal: 32,
                        ),
                      ),
                      child: Text(
                        'Get Started',
                        style: TextStyle(
                          color: Colors.orangeAccent,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Image at the bottom left corner
              SizedBox(height:20), // Reduced space above the image
              Align(
                alignment: Alignment.bottomLeft,
                child: Padding(
                  padding: const EdgeInsets.only(left: 0.0),
                  child: Image.asset(
                    'assets/images/splahsh_waffle.png', // Replace with your actual image path
                    height: 250,
                  ),
                ),
              ),
              SizedBox(height: 16), // Reduced space below the image
            ],
          ),
        ],
      ),
    );
  }
}
