import 'package:flutter/material.dart';

class ForgotPasswordScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Forgot Password'),
        backgroundColor: Colors.amber, // Customize the app bar color
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Image
              Center(
                child: Image.asset(
                  'assets/images/forgotpassword.png', // Replace with your image asset
                  height: 350,
                ),
              ),
              SizedBox(height: 20),
              // Title
              Text(
                "Forgot",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              Text(
                "Password?",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 10),
              // Description
              Center(
                child: Text(
                  "Don't Worry It's happens",
                  style: TextStyle(
                    fontSize: 22,
                    color: Colors.amber,
                  ),
                ),
              ),
               Center(
                 child: Text(
                  "Enter your registered email or phone number.",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.black54,
                  ),
                               ),
               ),
              SizedBox(height: 30),
              // Email or Phone Input
              TextField(
                decoration: InputDecoration(
                  labelText: "Email or Phone",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              SizedBox(height: 20),
              // Reset Password Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    // Handle password reset logic here
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber, // Button color
                    padding: EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: Text(
                    "Send Reset Link",
                    style: TextStyle(fontSize: 18,color:Colors.black),
                    
                  ),
                ),
              ),
              SizedBox(height: 20),
              // Back to Login Button
              Center(
                child: TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text(
                    "Back to Login",
                    style: TextStyle(
                      color: Colors.amber,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
