import 'package:flutter/material.dart';

class SummaryCartScreen extends StatelessWidget {
  final List<Map<String, dynamic>> cartItems;

  SummaryCartScreen({required this.cartItems});

  @override
  Widget build(BuildContext context) {
    double totalCost = cartItems.fold(0, (sum, item) {
      return sum + (double.tryParse(item['price'].replaceAll('₹', '')) ?? 0) * item['count'];
    });

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow[700],
        title: Text('Cart Summary'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: cartItems.length,
                itemBuilder: (context, index) {
                  final item = cartItems[index];
                  return Card(
                    margin: EdgeInsets.symmetric(vertical: 8.0),
                    child: ListTile(
                      contentPadding: EdgeInsets.all(8.0),
                      leading: Image.asset('assets/images/index-${index + 1}.png', width: 60, height: 60),
                      title: Text(item['name']),
                      subtitle: Text('Price: ${item['price']}'),
                      trailing: Column(
                        children: [
                          Text('Qty: ${item['count']}'),
                          Text('Total: ₹${(double.tryParse(item['price'].replaceAll('₹', '')) ?? 0) * item['count']}'),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Total Cost: ₹${totalCost.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                // Handle checkout action
                print('Proceeding to checkout');
              },
              child: Text('Checkout'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.yellow[700],
                padding: EdgeInsets.symmetric(vertical: 15.0),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
