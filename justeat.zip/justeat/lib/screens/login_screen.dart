import 'package:flutter/material.dart';
import 'package:justeat/screens/forgotpassword.dart';
import 'package:justeat/screens/menu_card.dart';
import 'package:justeat/screens/register.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow[700], // Set background color to yellow
      appBar: AppBar(
        title: Text(''), // Empty title for AppBar to match background
        backgroundColor: Colors.yellow[700], // Match the AppBar color with the background
        elevation: 0, // Remove shadow to make it blend with the background
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset(
              'assets/images/loginscreen.png',
              height: 400,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Container(
                padding: const EdgeInsets.all(28.0), // Padding inside the white container
                margin: const EdgeInsets.only(top: 0.0), // Margin around the white container
                decoration: BoxDecoration(
                  color: Colors.white, // White background for the container
                  borderRadius: BorderRadius.circular(10.0), // Rounded corners
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min, // Minimize the size of the column to wrap content
                  children: [
                    Text(
                      'Welcome Back',
                      style: TextStyle(
                        color: Colors.yellow[700],
                        fontSize: 25,
                      ),
                    ),
                    SizedBox(height: 10), // Spacing below the title
                    Text(
                      'Login to your Account',
                      style: TextStyle(color: Colors.black54, fontSize: 16),
                    ),
                    SizedBox(height: 30), // Add spacing between title and form fields

                    // Mobile Number Field
                    TextField(
                      keyboardType: TextInputType.phone, // Specify input type for numbers
                      decoration: InputDecoration(
                        labelText: 'Mobile Number',
                        labelStyle: TextStyle(color: Colors.black54),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                    ),
                    SizedBox(height: 30.0), // Add spacing between fields

                    // Password Field
                    TextField(
                      obscureText: true, // Hide the password input
                      decoration: InputDecoration(
                        labelText: 'Password',
                        labelStyle: TextStyle(color: Colors.black54),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                    ),
                    SizedBox(height: 20.0), // Spacing between password and forgot password

                    // Forgot Password Button
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ForgotPasswordScreen(),
                            ),
                          );
                        },
                        child: Text(
                          'Forgot Password?',
                          style: TextStyle(color: Colors.yellow[700]), // Text color
                        ),
                      ),
                    ),
                    SizedBox(height: 20.0), // Add spacing between fields and button

                    // Login Button
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => MenuCardScreen(),
                          ),
                        );
                        // Handle login action
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.yellow[700], // Button background color
                        foregroundColor: Colors.white, // Button text color
                        padding: EdgeInsets.symmetric(
                            horizontal: 40, vertical: 15), // Button padding
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0), // Rounded corners
                        ),
                      ),
                      child: Text(
                        'Login',
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                    SizedBox(height: 20.0), // Spacing below the login button

                    // Register Prompt and Button
                    Text(
                      "I don't have an account?",
                      style: TextStyle(color: Colors.black54), // Text color
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => RegisterScreen()),
                        );
                        // Handle registration action
                      },
                      child: Text(
                        'Register',
                        style: TextStyle(
                          color: Colors.yellow[700],
                          fontSize: 18,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
