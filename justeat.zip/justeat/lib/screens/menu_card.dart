import 'package:flutter/material.dart';
import 'package:justeat/screens/fav.dart';
import 'package:justeat/screens/notification.dart';
import 'package:justeat/screens/review.dart';
import 'package:justeat/screens/summarycartscreen.dart';

class MenuCardScreen extends StatefulWidget {
  @override
  _MenuCardScreenState createState() => _MenuCardScreenState();
}

class _MenuCardScreenState extends State<MenuCardScreen> {
  final List<Map<String, dynamic>> items = [
    {'name': 'Hot Chocolate', 'price': '₹139', 'rating': 4.5, 'count': 0},
    {'name': 'Special Cakes', 'price': '₹380', 'rating': 4.5, 'count': 0},
    {'name': 'Fried Burger', 'price': '₹160', 'rating': 4.5, 'count': 0},
    {'name': 'Milk Shakes', 'price': '₹150', 'rating': 4.5, 'count': 0},
    {'name': 'Fried Chicken', 'price': '₹380', 'rating': 4.5, 'count': 0},
    {'name': 'Ice Creams', 'price': '₹125', 'rating': 4.5, 'count': 0},
  ];

  final List<Map<String, dynamic>> cart = [];

  int _selectedIndex = 0;

  void _updateItemCount(int index, int delta) {
    setState(() {
      items[index]['count'] = (items[index]['count'] + delta).clamp(0, 8);
    });
  }

  void _addToCart(int index) {
    final item = items[index];
    final cartItem = cart.firstWhere(
      (i) => i['name'] == item['name'],
      orElse: () => {'name': item['name'], 'price': item['price'], 'count': 0},
    );
    setState(() {
      if (cartItem['count'] == 0) {
        cart.add(item);
      } else {
        cartItem['count'] = item['count'];
      }
    });
  }

  void _viewCart() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SummaryCartScreen(cartItems: cart),
      ),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    switch (index) {
      case 0:
        Navigator.push(context,MaterialPageRoute(builder:(context)=>MenuCardScreen()),);
        break;
      case 1:
        Navigator.push(context,MaterialPageRoute(builder:(context)=>FavoriteItemsScreen()),);
        break;
      case 2:
        _viewCart();
        break;
      case 3:
         Navigator.push(context,MaterialPageRoute(builder:(context)=>ReviewScreen()),);
        break;
      case 4:
         Navigator.push(context,MaterialPageRoute(builder:(context)=>NotificationsScreen()),);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.yellow[700],
        leading: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              icon: Icon(Icons.location_on),
              color: Colors.black,
              iconSize: 30,
              onPressed: () {
                // Add your location icon action here
              },
            ),
            TextButton(
              onPressed: () {
                // Add your text button action here
              },
              child: Text(
                'Madurai',
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.filter_list),
            color: Colors.black,
            onPressed: () {
              // Add your filter action here
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(38.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'Find the ',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 28,
                      ),
                    ),
                    TextSpan(
                      text: 'Best ',
                      style: TextStyle(
                        color: Colors.amberAccent,
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    TextSpan(
                      text: 'delicious ',
                      style: TextStyle(
                        color: Colors.amber,
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    TextSpan(
                      text: 'Food Around You',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 30,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: TextField(
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.search, color: Colors.black54),
                      hintText: 'Search...',
                      hintStyle: TextStyle(color: Colors.black54),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: BorderSide(color: Colors.yellow[700]!),
                      ),
                      contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Text(
                  'Find',
                  style: TextStyle(
                    color: const Color.fromARGB(255, 168, 152, 152),
                    fontSize: 20,
                  ),
                ),
                SizedBox(width: 8.0),
                Text(
                  '6km',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                IconButton(
                  onPressed: () {
                    // Add your button action here
                  },
                  icon: Icon(Icons.arrow_right),
                  iconSize: 60,
                  color: Colors.amber,
                ),
                SizedBox(width: 8.0),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.amber,
                    borderRadius: BorderRadius.circular(10.0),
                    border: Border.all(
                      color: Colors.black,
                      width: 2.0,
                    ),
                  ),
                  child: Text(
                    'Upto 15% Offer',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 50,
                    padding: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      borderRadius: BorderRadius.circular(10.0),
                      border: Border.all(
                        color: Colors.black,
                        width: 2.0,
                      ),
                    ),
                    child: Row(
                      children: [
                        Image.asset(
                          'assets/images/chicken_pop.png',
                          height: 50,
                          width: 70,
                        ),
                        SizedBox(width: 0.2),
                        Text(
                          'Chicken Pops',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Container(
                    height: 50,
                    padding: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      borderRadius: BorderRadius.circular(10.0),
                      border: Border.all(
                        color: Colors.black,
                        width: 2.0,
                      ),
                    ),
                    child: Row(
                      children: [
                        Image.asset(
                          'assets/images/cheese-burger.png',
                          height: 50,
                          width: 90,
                        ),
                        SizedBox(width: 10),
                        Text(
                          'Burger',
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 30),
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 30.0,
                  mainAxisSpacing: 40.0,
                  childAspectRatio: 0.8,
                ),
                itemCount: items.length,
                itemBuilder: (context, index) {
                  return Stack(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                          color: Colors.yellow[700],
                          image: DecorationImage(
                            image: AssetImage('assets/images/index-${index + 1}.png'),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 10.0,
                        left: 10.0,
                        child: Container(
                          padding: EdgeInsets.all(8.0),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(8.0),
                            border: Border.all(
                              color: Colors.black54,
                              width: 2.0,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                items[index]['name'],
                                style: TextStyle(
                                  color: Colors.black54,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 22.0,
                                  shadows: [
                                    Shadow(
                                      blurRadius: 10.0,
                                      color: Colors.amber,
                                      offset: Offset(2.0, 2.0),
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                items[index]['price'],
                                style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18.0,
                                ),
                              ),
                              Row(
                                children: List.generate(5, (starIndex) {
                                  return Icon(
                                    starIndex < items[index]['rating']
                                        ? Icons.star
                                        : Icons.star_border,
                                    color: Colors.black,
                                    size: 20.0,
                                  );
                                }),
                              ),
                              SizedBox(height: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(width: 8),
                                  ElevatedButton(
                                    onPressed: () {
                                      // Add your add to cart action here
                                      _addToCart(index);
                                      print('${items[index]['name']} added to cart');
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.white,
                                      foregroundColor: Colors.black,
                                      side: BorderSide(color: Colors.black, width: 2.0),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10.0),
                                      ),
                                    ),
                                    child: Text('Add to Cart',style:TextStyle(
                                      color:Colors.yellow[700],
                                      fontSize:10,
                                    ),), // Added text here
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
     bottomNavigationBar: BottomNavigationBar(
  currentIndex: _selectedIndex,
  onTap: _onItemTapped,
  items: [
    BottomNavigationBarItem(
      icon: Icon(Icons.home),
      label: 'Home',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.favorite),
      label: 'Favorites',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.shopping_cart),
      label: 'Cart',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.rate_review),
      label: 'Reviews',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.notifications),
      label: 'Notifications',
    ),
  ],
  selectedItemColor: Colors.amber, // Color for the selected item's label
  unselectedItemColor: Colors.black54, // Color for the unselected item's label
  backgroundColor: Colors.white, // Background color of the BottomNavigationBar
  type: BottomNavigationBarType.fixed, // Fix the number of items
)
    );
  }
}
