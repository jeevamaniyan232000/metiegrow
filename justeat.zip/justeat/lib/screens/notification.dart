import 'package:flutter/material.dart';
class NotificationsScreen extends StatelessWidget {
  final List<Map<String, String>> notifications = [
    {
      'title': 'Order Shipped',
      'message': 'Your order has been shipped and is on the way.',
    },
    {
      'title': 'New Discount',
      'message': 'A new discount is available for your favorite items!',
    },
    {
      'title': 'Reminder',
      'message': 'Don\'t forget to check out our new arrivals.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notifications'),
        backgroundColor: Colors.amber,
      ),
      body: ListView.builder(
        itemCount: notifications.length,
        itemBuilder: (context, index) {
          final notification = notifications[index];
          final title = notification['title'] ?? 'No Title';
          final message = notification['message'] ?? 'No Message';

          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    spreadRadius: 2,
                    offset: Offset(2, 4),
                  ),
                ],
              ),
              child: ListTile(
                title: Text(
                  title,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(message),
              ),
            ),
          );
        },
      ),
    );
  }
}
