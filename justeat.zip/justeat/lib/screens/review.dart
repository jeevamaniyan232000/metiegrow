import 'package:flutter/material.dart';

class ReviewScreen extends StatelessWidget {
  final List<Map<String, dynamic>> reviews = [
    {
      'name': 'John Doe',
      'rating': 4.5,
      'comment': 'Great food, will order again!',
    },
    {
      'name': 'Jane Smith',
      'rating': 3.0,
      'comment': 'It was okay, could be better.',
    },
    {
      'name': 'Alex Johnson',
      'rating': 5.0,
      'comment': 'Absolutely fantastic! Highly recommend.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reviews'),
        backgroundColor: Colors.amber,
      ),
      body: ListView.builder(
        itemCount: reviews.length,
        itemBuilder: (context, index) {
          final review = reviews[index];
          final name = review['name'] ?? 'Anonymous';
          final rating = review['rating'] ?? 0.0;
          final comment = review['comment'] ?? 'No comments';

          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    spreadRadius: 2,
                    offset: Offset(2, 4),
                  ),
                ],
              ),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.amber,
                  child: Text(
                    name[0],
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                title: Text(
                  name,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Rating: ${rating.toStringAsFixed(1)} / 5'),
                    SizedBox(height: 4),
                    Text(comment),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
