import 'package:flutter/material.dart';

class SummaryCartScreen extends StatefulWidget {
  final List<Map<String, dynamic>> cartItems;

  SummaryCartScreen({required this.cartItems});

  @override
  _SummaryCartScreenState createState() => _SummaryCartScreenState();
}

class _SummaryCartScreenState extends State<SummaryCartScreen> {

  void _onItemTapped(int index) {
    setState(() {
      // Handle navigation to different screens based on index
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellow[700],
        title: Text('Cart Summary'),
      ),
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center, // Center items vertically
        children: [
          Container(
            child: Image.asset('assets/images/no_order.png'),
            padding: EdgeInsets.all(20.0),
          ),
          SizedBox(height: 20), // Spacing between image and text
          Text(
            'Cart Is Empty',
            style: TextStyle(
              color: Colors.amber,
              fontSize: 30,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10), // Spacing between texts
          Text(
            'Please Add Your Favorite',
            style: TextStyle(
              color: Colors.black,
              fontSize: 22,
            ),
          ),
          Text(
            'Items In Cart',
            style: TextStyle(
              color: Colors.black,
              fontSize: 22,
            ),
          ),
          SizedBox(height: 30), // Spacing before the button
          ElevatedButton(
            onPressed: () {
              // Handle add items action
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.yellow[700], // Background color
              foregroundColor: Colors.black, // Text color
              side: BorderSide(color: Colors.black, width: 2.0), // Border color and width
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0), // Border radius
              ),
              padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 15.0), // Button padding
            ),
            child: Text(
              'Add Your Favorite Items',
              style: TextStyle(
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
